<?php
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * Tagger - Advanced Tagging v2                                              *
 * Author: Artanis (Erik Youngren <artanis.00@gmail.com>)                    *
 * Do not remove this notice.                                                *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

class taggerTheme extends Themelet {
	public function build_tagger ($page) {
		global $config;
		$base_href = $config->get_string('base_href');
		
		$html = $this->tagger_window();
		
		$page->add_header(
			"<script type='text/javascript'>".
				"var Tagger = new Tagger();".
				"var base_href = '$base_href';".
			"</script>");
		$page->add_block( new Block(
			"Tagger",
			$html,
			"main",0));
	}
	function tagger_window() {
		$about_tagger = make_link("about/tagger");
		$html = <<< EOD
<div style='font-size:0.7em;'>Collapse this block to hide Tagger</div>
<a onclick='' class='tagger_js'>Reset Position</a><br/>
<a href='$about_tagger'>About Tagger</a>
<div id='tagger_window'>
	<div id='tagger_titlebar' title='Drag to move'>Tagger</div>
	<div id='tagger_filter'>
		<input type='text' id='tagger_filter-tags' value='' size='12'
			onfocus='this.select();' onkeyup='Tagger.searchRequest(this.value);'
			title='Type to search'>
		</input>
		<input type='button' value='Add' tag='' title='Add typed tag'
			onclick=''
		</input>
		<input type='button' value='Set' onclick='' title='Save data'></input>
		<br/>
		<label>Mode</label>
		<select onchange='Tagger.setMode("this.value");'>
			<option value='basic'>Basic Mode</option>
			<option value='list'>List Add</option>
			<option value='auto'>Auto Complete</option>
			<option value='tab'>Select Complete</option>
		</select>
	</div>
	<div id='tagger_body'></div>
</div>
EOD;
		return $html;
	}
}
?>
