<?php
class Tagger extends Extension {
	var $theme;
	
	public function receive_event ($event) {
		if(is_null($this->theme))
			$this->theme = get_theme_object("tagger", "taggerTheme");
			
		if(is_a($event,'DisplayingImageEvent')) {
			global $page;
			$this->theme->build_tagger($page);
		}
		
		if(is_a($event,'PageRequestEvent') && $event->page_name == 'tagger') {
			switch($event->get_arg(0)) {
				case "config":
				default:
					// tagger configuration
					break;
			}
		}
	}
}
if(isset($_GET['debug'])) add_event_listener( new tagger());

// Tagger AJAX source
class taggerXML extends Extension {
	var $limited_query = false;
	public function receive_event($event) {
		if(is_a($event,'PageRequestEvent')
			&& $event->page_name == "tagger"
			&& $event->get_arg(0) == "tags")
		{
			global $page;
			
			$s = isset($_GET['s'])?$_GET['s']:null;
			$results = $this->get_tags($s);
			$c = $results->_numOfRows;
			$limited = $this->limited_query? "limited=\"".$this->limited_query."\"":null;
			
			$tags = "";
			foreach($results as $tag) {
				$tags .= $this->tag_to_xml($tag);
			}
		
			$xml =
			"<?xml version=\"1.0\" encoding=\"UTF-8\"?>".
			"<taglist id=\"taglist\" s=\"$s\" rows=\"$c\" {$limited}>$tags</taglist>";
			$page->set_mode("data");
			$page->set_type("text/xml");
			$page->set_data($xml);
		}
	}
	
	function get_tags ($s) {
		global $database;
		global $config;
		
/*		$tags_min =
			(isset($_GET['tagger_min']) && $_GET['tagger_min']>0)?
			$_GET['tagger_min']:$config->get_int('ext-tagger_tags-min',2);
*/		
		$p = strlen($s) == 1? " ":"\_";

		$hidden = $config->get_string(
			'ext-tagger_show-hidden','N')=='N' ?
			" AND substring(tag,1,1) != '.' " : null;
		
		$match = " concat(?,tag) LIKE ? AND count>0 ";
		
		$t = $database->Execute(
			"SELECT COUNT(*)
			FROM `tags`
			WHERE {$match} {$hidden}",
			array($p,"%".$p.$s."%"));
		$t = $t->fields['COUNT(*)'];
		
		if($t > 60) {
			$this->limited_query = $t;
			$result = $database->Execute(
				"SELECT *
				FROM
					(	SELECT *
						FROM `tags`
						WHERE {$match} {$hidden}
						ORDER BY count DESC
						LIMIT 0,30
					)	AS `c_tag`
				ORDER BY tag",
				array($p,"%".$p.$s."%"));
		} else {
			$this->limited = null;
			$result = $database->Execute(
				"SELECT *
				FROM `tags`
				WHERE {$match} {$hidden}
				ORDER BY tag",
				array($p,"%".$p.$s."%"));
		}
		
		return $result;
	}
	
	function tag_to_xml ($tag) {
		return
			"<tag ".
				"id=\"".$tag['id']."\" ".
				"name=\"".html_escape($tag['tag'])."\" ".
				"count=\"".$tag['count']."\" />";
	}
	
	function trim_tag($s,$len=80,$br=" ") {
		if(strlen($s) > $len) {
			$s = substr($s, 0,$len-1);
			$s = substr($s,0, strrpos($s,$br))."...";
		}
		return $s;
	}
}
add_event_listener( new taggerXML(),10);
?>
