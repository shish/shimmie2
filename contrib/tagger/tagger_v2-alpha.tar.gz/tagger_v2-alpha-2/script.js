/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *\
* Tagger - Advanced Tagging v2                                                *
* Author: Artanis (Erik Youngren <artanis.00@gmail.com>)                      *
* Do not remove this notice.                                                  *
\* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

/* Tagger Window Object
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
function Tagger() {
// components
	this.t_parent  = null;
	this.t_title   = null;
	this.t_toolbar = null;
	this.t_menu    = null;
	this.t_body    = null;
	this.t_tags    = null;
	this.t_form    = null;
// data
	this.searchTags  = null;
	this.appliedTags = null;
// methods
	this.initialize     = initialize;
	this.submit         = submit;
	this.searchRequest  = searchRequest;
	this.searchReceive  = searchReceive;
	this.tagListReceive = tagListReceive;
	this.tagPublish     = tagPublish;
	this.attachTagClick = attachTagClick;
	this.createTag      = createTag;
	this.buildPages     = buildPages;
	this.tagsToString   = tagsToString;
	this.toggleTag      = toggleTag;
	
// definitions
	function initialize () {
	// components
		this.t_parent  = byId("tagger_parent");
		this.t_title   = byId("tagger_titlebar");
		this.t_toolbar = byId("tagger_toolbar");
		this.t_menu    = byId("tagger_p-menu");
		this.t_body    = byId("tagger_body");
		this.t_tags    = byId("tagger_tags");
		this.t_form    = this.t_tags.parentNode;
	//pages
		//this.buildPages();
	// initial data
		ajaxXML(query+"/"+image_id,tagListReceive);
		
	}
	function submit() {
		this.t_tags.value = Tagger.tagsToString(Tagger.appliedTags);
		this.t_form.submit();
	}
	function searchRequest(s) {
		var s_query = query+"?s="+sqlescape(s);

		if(!this.searchTags) {
			ajaxXML(s_query,searchReceive);
			return true;
		} else {
			var prv_s = this.searchTags.getAttribute('query');
		
			if(s==prv_s) {
				return false;
			}else if(!s || s.length <= 2 || s.length<prv_s.length ||
				this.searchTags.getAttribute("max"))
			{
				ajaxXML(s_query,searchReceive);
				return true;
				
			} else if(s.length > 2 && s.match(reescape(prv_s))) {
				var len = this.searchTags.childNodes.length;
				
				for (var i=len-1; i>=0; i--) {
					var tag = this.searchTags.childNodes[i];
					var t_name = tag.firstChild.data;
					
					if(!t_name.match(reescape(s))) {
						this.searchTags.removeChild(tag);
						//tag.setAttribute("style","display:none;");
					} else {
						//tag.setAttribute("style","");
					}
				}
				
				if (len != this.searchTags.childNodes.length) {
					this.searchTags.setAttribute('query',s);
				}
			}
		}
		return false;
	}
	function searchReceive(xml) {
		Tagger.searchTags = xml.getElementsByTagName("list")[0];
		tagPublish(Tagger.searchTags,byId("tagger_p-search"));
	}
	
	function tagListReceive(xml) {
		Tagger.appliedTags = xml.getElementsByTagName("list")[0];
		tagPublish(Tagger.appliedTags,byId("tagger_p-applied"));
	}
	function tagPublish(tag_list,page) {
		page.innerHTML = "";
		page.appendChild(tag_list);
		Tagger.attachTagClick(tag_list);
	}
	function attachTagClick(tag_list) {
		var len = tag_list.childNodes.length;
		
		for(var i=0; i<len;i++) {
			var tag = tag_list.childNodes[i];
			tag.onclick = function() { toggleTag(this); };
		}
	}
	function createTag(tag_name) {
		var tag = document.createElement("tag");
		tag.setAttribute("count","0");
		tag.setAttribute("id","newTag_"+tag_name);
		tag.appendChild(document.createTextNode(tag_name));
		return tag;
	}
	function buildPages () {
		var pages = getElementsByTagNames("div",byId("tagger_body"));
		var len = pages.length;
		for(var i=0; i<len; i++) {
			this.t_menu.innerHTML += "<li onclick='Tagger.togglePages("+
				"\""+pages[i].getAttribute("id")+"\")'>"+
				pages[i].getAttribute('name')+"</li>";
		}
	}
	function tagsToString(tags) {
		var len = tags.childNodes.length;
		var str = "";
		for (var i=0; i<len; i++) {
			str += tags.childNodes[i].firstChild.data+" ";
		}
		return str;
	}
	function toggleTag(tag) {
		if(tag.parentNode == Tagger.appliedTags) {
			Tagger.appliedTags.removeChild(tag);
		} else {
			Tagger.appliedTags.appendChild(tag);
		}
	}
}

/* AJAX
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
function ajaxXML(url, callback) {
	var http = getHTTPObject();
	http.open("GET", url, true);
	http.onreadystatechange = function() {
		if(http.readyState == 4) callback(http.responseXML);
	}
	http.send(null);
}

/* Miscellaneous Code
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

// Quirksmode
// http://www.quirksmode.org/dom/getElementsByTagNames.htmlgetElementById
function getElementsByTagNames(list,obj) {
	if (!obj) var obj = document;
	var tagNames = list.split(',');
	var resultArray = new Array();
	for (var i=0;i<tagNames.length;i++) {
		var tags = obj.getElementsByTagName(tagNames[i]);
		for (var j=0;j<tags.length;j++) {
			resultArray.push(tags[j]);
		}
	}
	var testNode = resultArray[0];
	if (!testNode) return [];
	if (testNode.sourceIndex) {
		resultArray.sort(function (a,b) {
				return a.sourceIndex - b.sourceIndex;
		});
	}
	else if (testNode.compareDocumentPosition) {
		resultArray.sort(function (a,b) {
				return 3 - (a.compareDocumentPosition(b) & 6);
		});
	}
	return resultArray;
}

// ripped from a forum.
// todo: cite source
function reescape(str){
	var resp="()?:=[]*+{}^$|/,.!\\"
	var found=false
	var ret=""
	for(var i=0;i<str.length;i++) {
		found=false
		for(var j=0;j<resp.length;j++) {
			if(str.charAt(i)==resp.charAt(j)) {
				found=true;break
			}
		}
		if(found) {
			ret+="\\"
		}
		ret+=str.charAt(i)
	}
	return ret
}

// Modified from above
function sqlescape(str){
	var resp="#%&_"
	var found=false
	var ret=""
	for(var i=0;i<str.length;i++) {
		found=false
		for(var j=0;j<resp.length;j++) {
			if(str.charAt(i)==resp.charAt(j)) {
				found=true;break
			}
		}
		if(found) {
			ret+="\\"
		}
		ret+=str.charAt(i)
	}
	return ret
}
