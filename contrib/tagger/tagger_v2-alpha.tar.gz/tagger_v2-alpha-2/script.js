/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * Tagger - Advanced Tagging v2                                              *
 * Author: Artanis (Erik Youngren <artanis.00@gmail.com>)                    *
 * Do not remove this notice.                                                *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

function Tagger() {
	// Variables
	var tagXML         = false;
	var mode           = 'basic'; // enum('basic','list','auto','tab')
	// Methods
	this.searchRequest = searchRequest;
	this.tagRequest    = tagRequest;
	this.tagReceive    = tagReceive;
	this.xmlToHTML     = xmlToHTML;
	this.setMode       = setMode;
	
	// Definitions	
	function searchRequest(s) {
		if (tagXML) {
			var old_s = tagXML.getAttribute('s');
			
			if(s == old_s) {
				// identical search, deny.
				return false;
			}
			else if(!s || s.length <= 2 || s.length < old_s.length ||
					tagXML.getAttribute('limited')) {
				// In order of appearance:
				//		Blank search
				//		Single or double letter search
				//		New has greater scope than last
				//		Previous search was limited
				// All allow, because each has the potential to return a
				// different set of tags.

				tagRequest(s);
				return true;
			}
			else if(s.length > 2 && s.match(reescape(old_s))) {
				// new search is sub-set of old. remove non-matches.
				
				l = tagXML.childNodes.length;
				for(var i=l-1; i>=0; i--) {
					var tag = tagXML.childNodes[i];
					var t_name = tag.getAttribute('name');
					if(!t_name.match(reescape(s)))
						tagXML.removeChild(tag);
				}
				
				if(l != tagXML.childNodes.length) {
					// update old_s if node count changed.
					// If the search comes back to here, we will need to query
					// for the larger set.
					tagXML.setAttribute('s',s);
				}
				// populate list with edited tagXML
				xmlToHTML();
				return true;
			}
		} else {
			// first search, allow.
			tagRequest(s);
		}
	}
	function tagRequest (s) {
		ajaxXML(query+"?s="+sqlescape(s),tagReceive);
	}
	function tagReceive (s) {
		tagXML = s.getElementsByTagName('taglist')[0];
		xmlToHTML();
	}
	function xmlToHTML() {
		var tagList = byId('tagger_body');
		var l = tagXML.childNodes.length;
		
		// Limited return indicator, remove|replace in release
		if(tagXML.getAttribute('limited')) byId('tagger_window').style.color='red';
		
		tagList.innerHTML = "";
		for(var i=0; i<l; i++) {
			tagList.innerHTML += tagToHTML(tagXML.childNodes[i]);
		}
	}
	function tagToHTML (tag) {
		var t_name = tag.getAttribute('name');
//		var t_count = tag.getAttribute('count');
		var t_id = tag.getAttribute('id');
		switch(mode) {
			case 'basic':
			default:
				t_html = "<a class='tagger_js' id='"+t_id+"'>"+t_name+"</a>";
				break;
			case 'list':
				break;
			case 'auto':
				break;
			case 'tab':
				break;
		}
		return t_html;
	}
	function setMode(m) {
		mode = m;
	}
}

function ajaxXML(url, callback) {
	var http = getHTTPObject();
	http.open("GET", url, true);
	http.onreadystatechange = function() {
		if(http.readyState == 4) callback(http.responseXML);
	}
	http.send(null);
}

function tagger_reset_position (x,y) {
	
}

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *\
*                                 Copied Code                                 *
\* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

// http://www.quirksmode.org/js/findpos.html
function findPos(obj) {
	var curleft = curtop = 0;
	if (obj.offsetParent) {
		curleft = obj.offsetLeft
		curtop = obj.offsetTop
		while (obj = obj.offsetParent) {
			curleft += obj.offsetLeft
			curtop += obj.offsetTop
		}
	}
	return [curleft,curtop];
}

// ripped from a forum.
// todo: cite source
function reescape(str){
	var resp="()?:=[]*+{}^$|/,.!\\"
	var found=false
	var ret=""
	for(var i=0;i<str.length;i++) {
		found=false
		for(var j=0;j<resp.length;j++) {
			if(str.charAt(i)==resp.charAt(j)) {
				found=true;break
			}
		}
		if(found) {
			ret+="\\"
		}
		ret+=str.charAt(i)
	}
	return ret
}
// Modified from above
function sqlescape(str){
	var resp="#%&_"
	var found=false
	var ret=""
	for(var i=0;i<str.length;i++) {
		found=false
		for(var j=0;j<resp.length;j++) {
			if(str.charAt(i)==resp.charAt(j)) {
				found=true;break
			}
		}
		if(found) {
			ret+="\\"
		}
		ret+=str.charAt(i)
	}
	return ret
}
